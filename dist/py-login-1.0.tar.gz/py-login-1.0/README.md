
# PYLOGIN


### The project
Pylogin is colection of codes that provide a simple login system for your web app - site.

### How to use
After executing the Pylogin initialization script(pylogin)  you can implement you Reactjs project under the Link tag inside log/src/Dashboard.js

### Bugs
In case that you find a bug report it on github, or send an e-mail to bernardo.contato2020@gmail.com


### Instalation
To install Pylogin, run in a terminal 
	`pip install pylogin`

----------------------------
### More information
To more information - documentation go to ouer site or github

| name   |      link      |  Description |
|----------|:-------------:|------:|
| Site |  www.pylogin.it | Big documentation - General inf. |
| Github | github.com/jazzman07/pylogin/      |  Code - Small Documentation  |
